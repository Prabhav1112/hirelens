"""
Thin wrapper around the Anthropic SDK used by every agent in the pipeline.

Every agent call in HireLens must be:
  1. Independent (no shared conversation state between agents)
  2. Grounded (forced to quote resume/transcript text)
  3. Structured (returns clean JSON we can validate with pydantic)

This module centralises those concerns so agents.py / debate.py / judge.py
stay short and readable.
"""

import json
import re
from typing import Any, Dict, Optional

from anthropic import Anthropic

from app.config import ANTHROPIC_API_KEY, ANTHROPIC_MODEL

_client: Optional[Anthropic] = None


def get_client() -> Anthropic:
    global _client
    if _client is None:
        if not ANTHROPIC_API_KEY:
            raise RuntimeError(
                "ANTHROPIC_API_KEY is not set. Copy .env.example to .env and add your key."
            )
        _client = Anthropic(api_key=ANTHROPIC_API_KEY)
    return _client


def _strip_code_fences(text: str) -> str:
    text = text.strip()
    text = re.sub(r"^```(json)?", "", text.strip(), flags=re.IGNORECASE)
    text = re.sub(r"```$", "", text.strip())
    return text.strip()


def _extract_json_block(text: str) -> str:
    """Best-effort extraction of the first top-level JSON object/array in text."""
    text = _strip_code_fences(text)
    # Fast path: already valid JSON
    try:
        json.loads(text)
        return text
    except json.JSONDecodeError:
        pass

    # Fallback: find the first balanced {...} or [...] block
    for open_ch, close_ch in (("{", "}"), ("[", "]")):
        start = text.find(open_ch)
        if start == -1:
            continue
        depth = 0
        for i in range(start, len(text)):
            if text[i] == open_ch:
                depth += 1
            elif text[i] == close_ch:
                depth -= 1
                if depth == 0:
                    candidate = text[start : i + 1]
                    try:
                        json.loads(candidate)
                        return candidate
                    except json.JSONDecodeError:
                        break
    raise ValueError(f"Could not extract valid JSON from model response:\n{text[:1000]}")


def call_llm_json(
    system: str,
    user: str,
    max_tokens: int = 2000,
    temperature: float = 0.4,
    model: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Calls the model with a strict 'return JSON only' instruction and parses the result.
    Raises on repeated failure so the caller can decide how to degrade gracefully.
    """
    client = get_client()
    system_full = (
        system.strip()
        + "\n\nCRITICAL OUTPUT RULE: Respond with ONLY a single valid JSON object. "
        "No markdown code fences, no preamble, no explanation outside the JSON."
    )

    last_err: Optional[Exception] = None
    for attempt in range(2):
        response = client.messages.create(
            model=model or ANTHROPIC_MODEL,
            max_tokens=max_tokens,
            temperature=temperature,
            system=system_full,
            messages=[{"role": "user", "content": user}],
        )
        raw_text = "".join(
            block.text for block in response.content if getattr(block, "type", None) == "text"
        )
        try:
            json_str = _extract_json_block(raw_text)
            return json.loads(json_str)
        except (ValueError, json.JSONDecodeError) as e:
            last_err = e
            # On retry, ask the model to fix its own output
            user = (
                "Your previous response could not be parsed as valid JSON. "
                "Re-send ONLY the corrected, valid JSON object, nothing else.\n\n"
                f"Previous response:\n{raw_text[:3000]}"
            )
            continue
    raise RuntimeError(f"LLM did not return parseable JSON after retries: {last_err}")
