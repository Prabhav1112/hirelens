import os
from dotenv import load_dotenv

load_dotenv()

ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
ANTHROPIC_MODEL = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-5")
CORS_ORIGINS = os.getenv("CORS_ORIGINS", "*")
ENABLE_VOICE = os.getenv("ENABLE_VOICE", "true").lower() == "true"
OUTPUT_DIR = os.getenv("OUTPUT_DIR", "outputs")

os.makedirs(OUTPUT_DIR, exist_ok=True)
