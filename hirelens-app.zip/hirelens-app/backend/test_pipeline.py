"""
Quick manual test — runs the full HireLens pipeline against the sample data
and pretty-prints the final report. Useful for a fast sanity check before
wiring up the frontend.

Usage:
    python test_pipeline.py
"""

import asyncio
import json

from app.pipeline import run_full_pipeline


def load(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


async def main():
    resume = load("sample_data/resume.txt")
    transcript = load("sample_data/transcript.txt")
    job_description = load("sample_data/job_description.txt")

    report = await run_full_pipeline(
        resume_text=resume,
        transcript_text=transcript,
        job_description=job_description,
        target_role="Senior Backend Engineer",
        generate_voice=False,
    )

    print(json.dumps(report.model_dump(), indent=2))


if __name__ == "__main__":
    asyncio.run(main())
