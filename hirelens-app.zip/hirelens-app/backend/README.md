# HireLens Backend — Evidence-Driven AI Hiring Panel

FastAPI backend implementing the full HireLens pipeline:

```
Candidate Inputs (Resume + Transcript + Job Description)
        │
        ▼
Candidate Profile Builder        (1 LLM call — facts only, no judgement)
        │
        ├──────────────┬──────────────┬──────────────┐
        ▼              ▼              ▼              ▼
  Technical Agent   HR Agent   Hiring Manager   Skeptic Agent   <- 4 INDEPENDENT,
  (isolated LLM      (isolated  Agent (isolated  (isolated       ISOLATED calls,
   call)              call)      call)            call)          run in parallel
        │              │              │              │
        └──────────────┴──────────────┴──────────────┘
                        ▼
                     DEBATE            (1 LLM call — agents respond directly
                        │               to each other's specific points)
                        ▼
                  FINAL JUDGE          (1 LLM call — weighted reasoning,
                        │               NOT a simple average)
                        ▼
                 FINAL REPORT          (assembled, + optional bonus TTS)
```

## Why this satisfies the challenge requirements

1. **Candidate Profile Builder** — `app/profile_builder.py`. One LLM call, extraction only
   (no scoring), producing the shared `CandidateProfile` every agent consumes.
2. **4 independent agents** — `app/agents/`. Each agent (`technical.py`, `hr.py`,
   `hiring_manager.py`, `skeptic.py`) is a **separate, isolated LLM call** via
   `run_independent_agent()` in `app/agents/base.py`. They are fired in parallel
   (`asyncio.gather` in `app/pipeline.py`) and structurally **cannot** see each other's output —
   there is no shared conversation state between them. Every strength/concern an agent claims
   must include a **verbatim quote** from the resume or transcript (enforced in the prompt
   schema and validated with pydantic).
3. **Debate step** — `app/debate.py`. A dedicated LLM call that receives all four independent
   opinions and is instructed to produce a real multi-turn debate: agents must reference each
   other by name and by specific point/quote, agreeing, disagreeing, or revising their score —
   with at least one agent's score actually changing because of another agent's argument.
   Unresolved disagreements are captured explicitly.
4. **Final Decision Step** — `app/judge.py`. A separate "Final Judge" LLM call that assigns a
   **weight and justification per agent** (not a fixed average), computes a `weighted_score`,
   and can let an unresolved red flag (e.g. from the Skeptic) cap the recommendation even if the
   naive average would look fine.
5. **Final Report** — `app/report.py` + the `FinalReport` pydantic model in `app/models.py`:
   final recommendation, confidence, strengths, concerns, and unresolved agent disagreements.
6. **Bonus: Voice debate** — `app/voice.py` synthesizes the debate transcript into an mp3 via
   gTTS (no extra API key required) when `generate_voice=true` is passed to the API.

## Setup (do this first)

```bash
cd hirelens-backend
cp .env.example .env
# then edit .env and paste your ANTHROPIC_API_KEY
```

## Run

```bash
./run.sh
```

This creates a venv, installs dependencies, and starts the server at
`http://localhost:8000`. Interactive API docs are automatically available at
`http://localhost:8000/docs`.

If you'd rather do it manually:

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

### Quick sanity check without the frontend

```bash
python test_pipeline.py
```

Runs the whole pipeline against the bundled `sample_data/` resume + transcript + job
description and prints the final JSON report to stdout. Good for confirming your API key
works before wiring up the frontend.

## API

### `GET /api/health`
Simple liveness check.

### `POST /api/analyze` (multipart/form-data) — use this if your frontend uploads files
| field | type | required | notes |
|---|---|---|---|
| `resume` | file | yes | `.pdf`, `.docx`, or `.txt` |
| `transcript` | file | yes | `.pdf`, `.docx`, or `.txt` |
| `job_description` | text | no | plain text job description |
| `job_description_file` | file | no | alternative to the text field above |
| `target_role` | text | no | e.g. "Senior Backend Engineer" |
| `generate_voice` | bool | no | if `true`, also generates a debate mp3 (bonus) |

### `POST /api/analyze-text` (application/json) — use this if your frontend already has raw text
```json
{
  "resume_text": "...",
  "transcript_text": "...",
  "job_description": "...",
  "target_role": "Senior Backend Engineer",
  "generate_voice": false
}
```

Both endpoints return a `FinalReport` JSON object (see `app/models.py` for the exact shape):
- `candidate_profile`
- `independent_opinions` (4 agents, pre-debate)
- `debate` (transcript + revised_opinions + unresolved_disagreements)
- `final_decision` (recommendation, confidence_level, weighted_score, agent_weights, reasoning)
- `strengths_summary` / `concerns_summary` / `unresolved_disagreements` (flattened, report-ready)
- `voice_debate_url` (nullable — set when `generate_voice=true` succeeded)

### `GET /api/audio/{filename}`
Serves the generated bonus debate mp3 referenced by `voice_debate_url`.

## CORS

Wide open (`*`) by default for fast hackathon iteration — set `CORS_ORIGINS` in `.env` to a
comma-separated origin list before you demo/ship for real.

## Notes on model choice

Defaults to `claude-sonnet-5` (set via `ANTHROPIC_MODEL` in `.env`). Swap to a faster/cheaper
model there if you hit rate limits during the demo — the whole pipeline is model-agnostic as
long as it can follow the "JSON only" instruction, which `app/llm_client.py` also defensively
retries/repairs if the model adds any stray text.

## Folder structure

```
hirelens-backend/
├── app/
│   ├── main.py            FastAPI app + routes
│   ├── pipeline.py         orchestrates the full flow
│   ├── config.py           env/config loading
│   ├── models.py           all pydantic schemas (profile, opinions, debate, decision, report)
│   ├── llm_client.py        Anthropic API wrapper + robust JSON parsing
│   ├── file_parser.py       pdf/docx/txt -> text extraction
│   ├── profile_builder.py   Step 1
│   ├── agents/
│   │   ├── base.py          shared isolated-agent-call machinery
│   │   ├── technical.py     Step 2a
│   │   ├── hr.py             Step 2b
│   │   ├── hiring_manager.py Step 2c
│   │   └── skeptic.py        Step 2d
│   ├── debate.py            Step 3
│   ├── judge.py             Step 4
│   ├── report.py            Step 5 (assembly)
│   └── voice.py             bonus TTS
├── sample_data/             demo resume/transcript/job description
├── test_pipeline.py         CLI smoke test
├── run.sh                   one-command local run
├── requirements.txt
└── .env.example
```
