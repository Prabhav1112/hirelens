#!/usr/bin/env bash
# Starts the HireLens backend (FastAPI, :8000) and frontend (Vite, :5173) together.
# Ctrl+C stops both.
set -e
cd "$(dirname "$0")"

cleanup() {
  echo ""
  echo "Stopping HireLens..."
  kill 0
}
trap cleanup EXIT INT TERM

echo "=== Starting backend ==="
(cd backend && ./run.sh) &
BACKEND_PID=$!

sleep 2

echo "=== Starting frontend ==="
(cd frontend && ./run.sh) &
FRONTEND_PID=$!

echo ""
echo "HireLens is starting:"
echo "  Backend:  http://localhost:8000  (docs at /docs)"
echo "  Frontend: http://localhost:5173"
echo ""

wait $BACKEND_PID $FRONTEND_PID
