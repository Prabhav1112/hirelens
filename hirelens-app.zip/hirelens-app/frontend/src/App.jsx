import React, { useState } from "react";
import {
  Aperture, Plus, FileText, Upload, CheckCircle2, Circle, ChevronRight,
  BadgeCheck, Quote, Sparkles, ShieldAlert, Users, Wrench, Target,
  MessageSquare, ArrowRight, RefreshCw, ThumbsUp, ThumbsDown, AlertTriangle,
  BarChart3, Clock, ChevronLeft, LayoutGrid, FileCheck2, HelpCircle,
  Volume2, XCircle
} from "lucide-react";
import { analyzeCandidateFiles, audioUrl } from "./api.js";

/* ---------------- tokens ---------------- */
const INK = "#0B1220";
const GOLD = "#C9962F";

// id (frontend-internal) -> matching agent_name string returned by the backend
const AGENTS = {
  technical: { name: "Technical Agent", role: "Skill & depth", color: "#1C7C72", bg: "#EAF5F3", icon: Wrench },
  culture: { name: "HR / Culture Agent", role: "Comms & integrity", color: "#7A56C7", bg: "#F1EDFB", icon: Users },
  manager: { name: "Hiring Manager Agent", role: "Role fit & value", color: "#2A5CAA", bg: "#EAF0FA", icon: Target },
  skeptic: { name: "Skeptic Agent", role: "Contradictions & risk", color: "#B5482F", bg: "#FBEEEA", icon: ShieldAlert },
};
// reverse lookup: backend agent_name -> internal id
const AGENT_NAME_TO_ID = Object.fromEntries(Object.entries(AGENTS).map(([id, a]) => [a.name, id]));

const REC_COLORS = {
  "Strong Hire": "#1E8A57",
  Hire: "#3E9C6B",
  "Lean Hire": "#B58B2A",
  "No Hire": "#C06A3B",
  "Strong No Hire": "#B23A2E",
};

const RECENTS = [
  { name: "Priya Nandakumar", role: "Senior Backend Engineer", rec: "Strong Hire", date: "Aug 26" },
  { name: "Marcus Reid", role: "Product Designer", rec: "No Hire", date: "Aug 24" },
  { name: "Wei Chen", role: "Data Scientist", rec: "Hire", date: "Aug 21" },
];

/* ---------------- small building blocks ---------------- */
function Bracketed({ children, color = GOLD }) {
  return (
    <div className="relative pl-4 pr-3 py-2.5" style={{ background: "#FBF8F1" }}>
      <span className="absolute left-0 top-0 w-2.5 h-2.5 border-l-2 border-t-2" style={{ borderColor: color }} />
      <span className="absolute right-0 top-0 w-2.5 h-2.5 border-r-2 border-t-2" style={{ borderColor: color }} />
      <span className="absolute left-0 bottom-0 w-2.5 h-2.5 border-l-2 border-b-2" style={{ borderColor: color }} />
      <span className="absolute right-0 bottom-0 w-2.5 h-2.5 border-r-2 border-b-2" style={{ borderColor: color }} />
      {children}
    </div>
  );
}

function Evidence({ quote, source }) {
  if (!quote) {
    return (
      <Bracketed>
        <p className="text-[12px] italic" style={{ color: "#9A8A5E" }}>No supporting quote available.</p>
      </Bracketed>
    );
  }
  return (
    <Bracketed>
      <div className="flex gap-2 items-start">
        <Quote size={13} className="mt-0.5 shrink-0" style={{ color: GOLD }} />
        <div>
          <p className="text-[12.5px] leading-relaxed" style={{ fontFamily: "JetBrains Mono, monospace", color: "#3A3428" }}>
            "{quote}"
          </p>
          {source && <p className="text-[10.5px] mt-1 uppercase tracking-wide" style={{ color: "#9A8A5E" }}>{source}</p>}
        </div>
      </div>
    </Bracketed>
  );
}

function Confidence({ value, color }) {
  const v = Math.max(0, Math.min(100, Number(value) || 0));
  return (
    <div className="flex items-center gap-2">
      <div className="w-16 h-1.5 rounded-full bg-slate-200 overflow-hidden">
        <div className="h-full rounded-full" style={{ width: `${v}%`, background: color }} />
      </div>
      <span className="text-[11px] font-semibold" style={{ color }}>{v}%</span>
    </div>
  );
}

const STATUS_MAP = {
  AGREE: { c: "#1E8A57", bg: "#E9F6EF", icon: ThumbsUp },
  DISAGREE: { c: "#B23A2E", bg: "#FBEAE8", icon: ThumbsDown },
  REVISE: { c: "#B58B2A", bg: "#FBF3E2", icon: RefreshCw },
  CHALLENGE: { c: "#B23A2E", bg: "#FBEAE8", icon: AlertTriangle },
  CLARIFY: { c: "#2A5CAA", bg: "#EAF0FA", icon: HelpCircle },
};

function StatusPill({ status }) {
  const key = (status || "CLARIFY").toUpperCase();
  const m = STATUS_MAP[key] || STATUS_MAP.CLARIFY;
  const Icon = m.icon;
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10.5px] font-bold tracking-wide" style={{ color: m.c, background: m.bg }}>
      <Icon size={11} /> {key}
    </span>
  );
}

function EmptyState({ icon: Icon = FileText, title, subtitle }) {
  return (
    <div className="rounded-xl border border-dashed border-slate-300 bg-white p-10 text-center">
      <Icon size={22} className="mx-auto mb-2" color="#B7BEC9" />
      <p className="text-[13.5px] font-semibold" style={{ color: INK }}>{title}</p>
      {subtitle && <p className="text-[12px] text-slate-400 mt-1">{subtitle}</p>}
    </div>
  );
}

/* ---------------- shell ---------------- */
const STEPS = ["Setup", "Profile", "Agents", "Debate", "Decision"];

function Stepper({ active, onJump, canJump }) {
  return (
    <div className="flex items-center gap-1.5">
      {STEPS.map((s, i) => (
        <React.Fragment key={s}>
          <button
            onClick={() => canJump(i) && onJump(i)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[12px] font-medium transition disabled:opacity-40"
            disabled={!canJump(i)}
            style={i === active
              ? { background: INK, color: "#fff" }
              : i < active
              ? { color: "#1E8A57" }
              : { color: "#9AA3B2" }}
          >
            {i < active ? <CheckCircle2 size={13} /> : <Circle size={13} />}
            {s}
          </button>
          {i < STEPS.length - 1 && <ChevronRight size={13} color="#CBD2DE" />}
        </React.Fragment>
      ))}
    </div>
  );
}

function Logo({ dark }) {
  return (
    <div className="flex items-center gap-2">
      <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: dark ? "#fff" : INK }}>
        <Aperture size={17} color={dark ? INK : "#fff"} />
      </div>
      <div className="leading-tight">
        <p className="font-bold text-[15px]" style={{ fontFamily: "Space Grotesk, sans-serif", color: dark ? "#fff" : INK }}>HireLens AI</p>
        <p className="text-[9.5px] tracking-widest uppercase" style={{ color: dark ? "#8FA0C4" : "#8A93A6" }}>Evidence-based hiring</p>
      </div>
    </div>
  );
}

/* ---------------- screens ---------------- */
function Dashboard({ goSetup, report }) {
  const stats = report
    ? [
        { label: "Agents evaluated", val: String(report.independent_opinions.length), icon: FileCheck2 },
        { label: "Final recommendation", val: report.final_decision.recommendation, icon: BarChart3 },
        { label: "Decision confidence", val: `${report.final_decision.confidence_level}%`, icon: Sparkles },
        { label: "Concerns flagged", val: String(report.concerns_summary.length), icon: ShieldAlert },
      ]
    : [
        { label: "Evaluated this month", val: "—", icon: FileCheck2 },
        { label: "Strong Hire rate", val: "—", icon: BarChart3 },
        { label: "Avg. agent agreement", val: "—", icon: Sparkles },
        { label: "Claims flagged", val: "—", icon: ShieldAlert },
      ];

  return (
    <div className="p-10 max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-[26px] font-bold" style={{ fontFamily: "Space Grotesk, sans-serif", color: INK }}>Good afternoon, Recruiter</h1>
          <p className="text-[13.5px] text-slate-500 mt-1">4 independent AI agents. One evidence-backed decision.</p>
        </div>
        <button onClick={goSetup} className="flex items-center gap-2 px-4 py-2.5 rounded-lg text-white text-[13.5px] font-semibold hover:opacity-90" style={{ background: INK }}>
          <Plus size={16} /> New Candidate
        </button>
      </div>

      <div className="grid grid-cols-4 gap-4 mb-8">
        {stats.map((s) => (
          <div key={s.label} className="rounded-xl border border-slate-200 bg-white p-4">
            <s.icon size={16} color="#8A93A6" />
            <p className="text-[20px] font-bold mt-2 truncate" style={{ fontFamily: "Space Grotesk, sans-serif", color: INK }}>{s.val}</p>
            <p className="text-[12px] text-slate-500">{s.label}</p>
          </div>
        ))}
      </div>

      {report ? (
        <>
          <p className="text-[12.5px] font-semibold uppercase tracking-wide text-slate-400 mb-3">Latest evaluation</p>
          <button onClick={goSetup} className="w-full flex items-center justify-between px-5 py-4 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-left">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full flex items-center justify-center text-[12px] font-bold text-white" style={{ background: INK }}>
                {(report.candidate_profile.name || "?").split(" ").map((n) => n[0]).join("").slice(0, 2)}
              </div>
              <div>
                <p className="text-[13.5px] font-semibold" style={{ color: INK }}>{report.candidate_profile.name}</p>
                <p className="text-[12px] text-slate-500">{report.candidate_profile.target_role || "Role not specified"}</p>
              </div>
            </div>
            <span className="text-[11.5px] font-bold px-2.5 py-1 rounded-full" style={{ color: REC_COLORS[report.final_decision.recommendation] || INK, background: "#F4F5F3" }}>
              {report.final_decision.recommendation}
            </span>
          </button>
        </>
      ) : (
        <EmptyState title="No candidates evaluated yet" subtitle="Click 'New Candidate' to run your first live analysis." />
      )}

      <p className="text-[12.5px] font-semibold uppercase tracking-wide text-slate-400 mt-8 mb-3">Demo examples</p>
      <div className="rounded-xl border border-slate-200 bg-white divide-y divide-slate-100 overflow-hidden opacity-70">
        {RECENTS.map((r) => (
          <div key={r.name} className="w-full flex items-center justify-between px-5 py-4 text-left">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full flex items-center justify-center text-[12px] font-bold text-white" style={{ background: "#8A93A6" }}>
                {r.name.split(" ").map((n) => n[0]).join("")}
              </div>
              <div>
                <p className="text-[13.5px] font-semibold" style={{ color: INK }}>{r.name}</p>
                <p className="text-[12px] text-slate-500">{r.role}</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-[11px] text-slate-400 flex items-center gap-1"><Clock size={12} />{r.date}</span>
              <span className="text-[11.5px] font-bold px-2.5 py-1 rounded-full" style={{ color: REC_COLORS[r.rec], background: "#F4F5F3" }}>{r.rec}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Setup({ onAnalyze, defaults }) {
  const [name, setName] = useState(defaults.candidateName || "");
  const [targetRole, setTargetRole] = useState(defaults.targetRole || "");
  const [jobDescription, setJobDescription] = useState(defaults.jobDescription || "");
  const [resumeFile, setResumeFile] = useState(null);
  const [transcriptFile, setTranscriptFile] = useState(null);
  const [generateVoice, setGenerateVoice] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  const canSubmit = resumeFile && transcriptFile && !busy;

  const run = async () => {
    if (!resumeFile || !transcriptFile) {
      setError("Please upload both a resume and an interview transcript.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const report = await analyzeCandidateFiles({
        resumeFile,
        transcriptFile,
        jobDescription,
        targetRole,
        generateVoice,
      });
      onAnalyze(report, { candidateName: name, targetRole, jobDescription });
    } catch (e) {
      setError(e.message || "Something went wrong while analyzing this candidate.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="p-10 max-w-3xl mx-auto">
      <h1 className="text-[22px] font-bold mb-1" style={{ fontFamily: "Space Grotesk, sans-serif", color: INK }}>New candidate</h1>
      <p className="text-[13px] text-slate-500 mb-7">Add source material — HireLens extracts a profile, then four agents evaluate independently.</p>

      <div className="grid grid-cols-2 gap-4 mb-4">
        <div>
          <label className="text-[12px] font-semibold text-slate-600">Candidate name (optional)</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Auto-detected from resume if left blank"
            className="mt-1 w-full border border-slate-300 rounded-lg px-3 py-2 text-[13.5px]"
          />
        </div>
        <div>
          <label className="text-[12px] font-semibold text-slate-600">Target role</label>
          <input
            value={targetRole}
            onChange={(e) => setTargetRole(e.target.value)}
            placeholder="e.g. Senior Backend Engineer"
            className="mt-1 w-full border border-slate-300 rounded-lg px-3 py-2 text-[13.5px]"
          />
        </div>
      </div>

      <label className="text-[12px] font-semibold text-slate-600">Job description (optional)</label>
      <textarea
        rows={3}
        value={jobDescription}
        onChange={(e) => setJobDescription(e.target.value)}
        placeholder="Paste the job description here for sharper Hiring Manager evaluation…"
        className="mt-1 w-full border border-slate-300 rounded-lg px-3 py-2 text-[13.5px] mb-4"
      />

      <div className="grid grid-cols-2 gap-4">
        <FileDrop
          label="Resume"
          sub="PDF, DOCX or TXT"
          file={resumeFile}
          onChange={setResumeFile}
        />
        <FileDrop
          label="Interview transcript"
          sub="PDF, DOCX or TXT"
          file={transcriptFile}
          onChange={setTranscriptFile}
        />
      </div>

      <label className="flex items-center gap-2 mt-4 text-[12.5px] text-slate-600">
        <input type="checkbox" checked={generateVoice} onChange={(e) => setGenerateVoice(e.target.checked)} />
        Generate bonus voice debate audio
      </label>

      {error && (
        <div className="mt-4 flex items-start gap-2 rounded-lg border border-rose-200 bg-rose-50 px-3 py-2.5">
          <XCircle size={15} className="mt-0.5 shrink-0 text-rose-500" />
          <p className="text-[12.5px] text-rose-700">{error}</p>
        </div>
      )}

      <button
        onClick={run}
        disabled={!canSubmit}
        className="mt-7 w-full flex items-center justify-center gap-2 py-3 rounded-lg text-white text-[14px] font-semibold hover:opacity-90 disabled:opacity-50"
        style={{ background: INK }}
      >
        {busy ? (
          <><RefreshCw size={16} className="animate-spin" /> Extracting profile &amp; briefing agents… (this can take ~30-90s)</>
        ) : (
          <><Sparkles size={16} /> Analyze Candidate</>
        )}
      </button>
    </div>
  );
}

function FileDrop({ label, sub, file, onChange }) {
  const inputId = `file-${label.replace(/\s+/g, "-")}`;
  return (
    <div className="relative border-2 border-dashed border-slate-300 rounded-xl p-5 text-center hover:border-slate-400">
      <input
        id={inputId}
        type="file"
        accept=".pdf,.docx,.txt,.md"
        className="absolute inset-0 opacity-0 cursor-pointer"
        onChange={(e) => onChange(e.target.files?.[0] || null)}
      />
      <Upload size={18} className="mx-auto mb-2" color="#8A93A6" />
      <p className="text-[13px] font-semibold" style={{ color: INK }}>{label}</p>
      <p className="text-[11.5px] text-slate-400 mb-2">{sub}</p>
      {file ? (
        <p className="inline-flex items-center gap-1 text-[11.5px] font-medium px-2 py-1 rounded-full" style={{ color: "#1E8A57", background: "#E9F6EF" }}>
          <CheckCircle2 size={12} /> {file.name}
        </p>
      ) : (
        <p className="inline-flex items-center gap-1 text-[11.5px] font-medium px-2 py-1 rounded-full text-slate-400 bg-slate-100">
          Click to upload
        </p>
      )}
    </div>
  );
}

function Profile({ report }) {
  if (!report) return <EmptyState title="No profile yet" subtitle="Run an analysis from the Setup step first." />;

  const p = report.candidate_profile;

  // Build a claims/evidence list from real agent-cited quotes: strengths read as
  // corroborated evidence, concerns read as claims that weren't fully corroborated.
  const seen = new Set();
  const claims = [];
  for (const op of report.independent_opinions) {
    for (const s of op.strengths) {
      const k = s.quote?.trim();
      if (k && !seen.has(k)) {
        seen.add(k);
        claims.push({ text: s.point, cite: s.quote, source: `${op.agent_name} · ${s.source}`, verified: true });
      }
    }
    for (const c of op.concerns) {
      const k = c.quote?.trim();
      if (k && !seen.has(k)) {
        seen.add(k);
        claims.push({ text: c.point, cite: c.quote, source: `${op.agent_name} · ${c.source}`, verified: false });
      }
    }
  }

  return (
    <div className="p-10 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div>
          <h1 className="text-[22px] font-bold" style={{ fontFamily: "Space Grotesk, sans-serif", color: INK }}>{p.name}</h1>
          <p className="text-[13px] text-slate-500">
            {[p.target_role, p.years_experience && `${p.years_experience} experience`, p.education?.[0]].filter(Boolean).join(" · ") || "No additional details extracted"}
          </p>
        </div>
        <div className="flex gap-2 flex-wrap">
          {(p.skills || []).slice(0, 6).map((t) => (
            <span key={t} className="text-[11px] font-medium px-2.5 py-1 rounded-full border border-slate-200 text-slate-600">{t}</span>
          ))}
        </div>
      </div>

      {p.summary && (
        <div className="rounded-xl border border-slate-200 bg-white p-4 mb-6">
          <p className="text-[12px] font-semibold uppercase tracking-wide text-slate-400 mb-1.5">Extracted summary</p>
          <p className="text-[13px] text-slate-600 leading-relaxed">{p.summary}</p>
        </div>
      )}

      <p className="text-[12.5px] font-semibold uppercase tracking-wide text-slate-400 mb-3">Claims &amp; evidence surfaced by the panel</p>
      {claims.length === 0 ? (
        <EmptyState title="No quote-backed claims surfaced" />
      ) : (
        <div className="space-y-3 mb-8">
          {claims.map((c, i) => (
            <div key={i} className="rounded-xl border border-slate-200 bg-white p-4 grid grid-cols-2 gap-4">
              <div>
                <span className="inline-flex items-center gap-1 text-[10.5px] font-bold px-2 py-0.5 rounded-full mb-2"
                  style={c.verified ? { color: "#1E8A57", background: "#E9F6EF" } : { color: "#B58B2A", background: "#FBF3E2" }}>
                  {c.verified ? <BadgeCheck size={11} /> : <AlertTriangle size={11} />}
                  {c.verified ? "SUPPORTED" : "FLAGGED"}
                </span>
                <p className="text-[13.5px]" style={{ color: INK }}>{c.text}</p>
              </div>
              <Evidence quote={c.cite} source={c.source} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function AgentCard({ id, opinion }) {
  const a = AGENTS[id];
  const Icon = a.icon;

  if (!opinion) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white p-4">
        <div className="flex items-center gap-2.5 mb-3">
          <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: a.bg }}>
            <Icon size={16} color={a.color} />
          </div>
          <div>
            <p className="text-[13.5px] font-bold" style={{ color: INK }}>{a.name}</p>
            <p className="text-[11px] text-slate-400">{a.role}</p>
          </div>
        </div>
        <p className="text-[12.5px] text-slate-400">No opinion returned by the backend for this agent.</p>
      </div>
    );
  }

  const topStrength = opinion.strengths?.[0];
  const topConcern = opinion.concerns?.[0];

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 flex flex-col">
      <div className="flex items-center gap-2.5 mb-3">
        <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: a.bg }}>
          <Icon size={16} color={a.color} />
        </div>
        <div className="flex-1">
          <p className="text-[13.5px] font-bold" style={{ color: INK }}>{a.name}</p>
          <p className="text-[11px] text-slate-400">{a.role}</p>
        </div>
        <span className="text-[13px] font-bold" style={{ color: a.color, fontFamily: "Space Grotesk, sans-serif" }}>{opinion.score}</span>
      </div>
      <Confidence value={opinion.confidence} color={a.color} />
      <p className="text-[12.5px] text-slate-600 mt-3 mb-3 leading-relaxed">{opinion.verdict}</p>
      <div className="grid grid-cols-2 gap-2 text-[11.5px] mb-3">
        <div>
          <p className="font-semibold text-emerald-700 mb-1">Strengths</p>
          <p className="text-slate-500 leading-snug">
            {opinion.strengths?.length ? opinion.strengths.map((s) => s.point).join("; ") : "None cited"}
          </p>
        </div>
        <div>
          <p className="font-semibold text-rose-700 mb-1">Concerns</p>
          <p className="text-slate-500 leading-snug">
            {opinion.concerns?.length ? opinion.concerns.map((c) => c.point).join("; ") : "None cited"}
          </p>
        </div>
      </div>
      <Evidence quote={topStrength?.quote || topConcern?.quote} source={(topStrength || topConcern)?.source} />
    </div>
  );
}

function Agents({ report }) {
  if (!report) return <EmptyState title="No agent opinions yet" subtitle="Run an analysis from the Setup step first." />;

  const byId = {};
  for (const op of report.independent_opinions) {
    const id = AGENT_NAME_TO_ID[op.agent_name];
    if (id) byId[id] = op;
  }

  return (
    <div className="p-10 max-w-6xl mx-auto">
      <h1 className="text-[22px] font-bold mb-1" style={{ fontFamily: "Space Grotesk, sans-serif", color: INK }}>Independent agent analysis</h1>
      <p className="text-[13px] text-slate-500 mb-6 flex items-center gap-1.5">
        <ShieldAlert size={13} /> Each agent evaluated in isolation — none could see the others' conclusions.
      </p>
      <div className="grid grid-cols-2 gap-4">
        {Object.keys(AGENTS).map((id) => <AgentCard key={id} id={id} opinion={byId[id]} />)}
      </div>
    </div>
  );
}

function Debate({ report }) {
  if (!report) return <EmptyState title="No debate yet" subtitle="Run an analysis from the Setup step first." />;

  const debate = report.debate;
  const revisedById = {};
  for (const r of debate.revised_opinions || []) revisedById[r.agent_name] = r;

  return (
    <div className="p-10 max-w-4xl mx-auto">
      <h1 className="text-[22px] font-bold mb-1" style={{ fontFamily: "Space Grotesk, sans-serif", color: INK }}>Debate room</h1>
      <p className="text-[13px] text-slate-500 mb-6">Agents challenge each other with evidence until they converge — or agree to disagree.</p>

      {report.voice_debate_url && (
        <div className="flex items-center gap-3 rounded-xl border border-slate-200 bg-white p-4 mb-5">
          <Volume2 size={16} color={GOLD} />
          <div className="flex-1">
            <p className="text-[12.5px] font-semibold" style={{ color: INK }}>Voice debate (bonus)</p>
            <audio controls src={audioUrl(report.voice_debate_url)} className="w-full mt-1.5" />
          </div>
        </div>
      )}

      {debate.transcript.length === 0 ? (
        <EmptyState title="No debate turns returned" />
      ) : (
        <div className="rounded-xl border border-slate-200 bg-white p-5 space-y-4 mb-6">
          {debate.transcript.map((m, i) => {
            const id = AGENT_NAME_TO_ID[m.speaker];
            const a = id ? AGENTS[id] : null;
            const Icon = a?.icon || MessageSquare;
            const changed = (m.stance || "").toLowerCase() === "revise";
            return (
              <div key={i} className="flex gap-3">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0" style={{ background: a?.bg || "#EEF1F5", border: changed ? `2px solid ${GOLD}` : "none" }}>
                  <Icon size={15} color={a?.color || "#8A93A6"} />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <p className="text-[12.5px] font-bold" style={{ color: a?.color || INK }}>{m.speaker}</p>
                    {m.addressed_to && <span className="text-[11px] text-slate-400">→ {m.addressed_to}</span>}
                    <StatusPill status={m.stance} />
                    {changed && (
                      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded" style={{ color: GOLD, background: "#FBF3E2" }}>POSITION CHANGED</span>
                    )}
                  </div>
                  <p className="text-[13px] leading-relaxed" style={{ color: INK }}>{m.message}</p>
                  {m.referenced_quote && (
                    <p className="text-[11.5px] mt-1.5 italic" style={{ color: "#9A8A5E" }}>"{m.referenced_quote}"</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {debate.unresolved_disagreements?.length > 0 && (
        <div className="rounded-xl border border-amber-200 bg-amber-50 p-4">
          <p className="text-[12px] font-semibold text-amber-800 mb-2 flex items-center gap-1.5"><AlertTriangle size={13} /> Unresolved disagreements</p>
          <ul className="space-y-1">
            {debate.unresolved_disagreements.map((u, i) => (
              <li key={i} className="text-[12.5px] text-amber-800">• {u}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

function Decision({ report, candidateName }) {
  if (!report) return <EmptyState title="No decision yet" subtitle="Run an analysis from the Setup step first." />;

  const fd = report.final_decision;
  const rec = fd.recommendation;
  const displayName = candidateName || report.candidate_profile.name;

  const positiveAgents = report.independent_opinions.filter((o) => o.score >= 60).length;
  const totalAgents = report.independent_opinions.length;
  const changedCount = (report.debate.revised_opinions || []).filter((r) => r.changed).length;
  const unresolvedCount = report.unresolved_disagreements?.length || 0;

  // Pick the most decisive quote: prefer the highest-weighted agent's first strength/concern.
  const sortedWeights = [...(fd.agent_weights || [])].sort((a, b) => b.weight - a.weight);
  let decisiveQuote = null;
  let decisiveSource = null;
  for (const w of sortedWeights) {
    const op = report.independent_opinions.find((o) => o.agent_name === w.agent_name);
    const ev = op?.strengths?.[0] || op?.concerns?.[0];
    if (ev) {
      decisiveQuote = ev.quote;
      decisiveSource = `${op.agent_name} · ${ev.source}`;
      break;
    }
  }

  return (
    <div className="p-10 max-w-5xl mx-auto">
      <div className="rounded-2xl p-6 mb-6 text-white" style={{ background: INK }}>
        <p className="text-[11px] uppercase tracking-widest text-slate-400 mb-1">Final recommendation</p>
        <div className="flex items-end justify-between flex-wrap gap-3">
          <div className="flex items-center gap-3 flex-wrap">
            <h1 className="text-[30px] font-bold" style={{ fontFamily: "Space Grotesk, sans-serif", color: REC_COLORS[rec] || "#fff" }}>{rec}</h1>
            <span className="text-[13px] text-slate-300">{displayName} · {report.candidate_profile.target_role || "Role not specified"}</span>
          </div>
          <Confidence value={fd.confidence_level} color="#7FD1AE" />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-[12px] font-semibold text-emerald-700 mb-2">Key strengths</p>
          <ul className="space-y-1.5">
            {report.strengths_summary.slice(0, 6).map((s, i) => <li key={i} className="text-[12.5px] text-slate-600 flex gap-2"><CheckCircle2 size={14} className="shrink-0 mt-0.5 text-emerald-600" />{s}</li>)}
            {report.strengths_summary.length === 0 && <li className="text-[12.5px] text-slate-400">None cited</li>}
          </ul>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-[12px] font-semibold text-rose-700 mb-2">Key concerns</p>
          <ul className="space-y-1.5">
            {report.concerns_summary.slice(0, 6).map((s, i) => <li key={i} className="text-[12.5px] text-slate-600 flex gap-2"><AlertTriangle size={14} className="shrink-0 mt-0.5 text-rose-500" />{s}</li>)}
            {report.concerns_summary.length === 0 && <li className="text-[12.5px] text-slate-400">None cited</li>}
          </ul>
        </div>
      </div>

      {decisiveQuote && (
        <>
          <p className="text-[12px] font-semibold uppercase tracking-wide text-slate-400 mb-2">Most decisive evidence</p>
          <div className="mb-5"><Evidence quote={decisiveQuote} source={decisiveSource} /></div>
        </>
      )}

      <div className="grid grid-cols-3 gap-4 mb-5">
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-[12px] font-semibold text-slate-500 mb-2">Agent agreement</p>
          <p className="text-[22px] font-bold" style={{ color: INK, fontFamily: "Space Grotesk, sans-serif" }}>{positiveAgents} / {totalAgents}</p>
          <p className="text-[11.5px] text-slate-400">agents scored ≥60/100</p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-[12px] font-semibold text-slate-500 mb-2">Position changes</p>
          <p className="text-[22px] font-bold" style={{ color: GOLD, fontFamily: "Space Grotesk, sans-serif" }}>{changedCount}</p>
          <p className="text-[11.5px] text-slate-400">agents revised their score after debate</p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-[12px] font-semibold text-slate-500 mb-2">Unresolved</p>
          <p className="text-[22px] font-bold" style={{ color: unresolvedCount ? "#B23A2E" : "#1E8A57", fontFamily: "Space Grotesk, sans-serif" }}>{unresolvedCount}</p>
          <p className="text-[11.5px] text-slate-400">{unresolvedCount ? "disagreements left open" : "fully resolved"}</p>
        </div>
      </div>

      {fd.agent_weights?.length > 0 && (
        <div className="rounded-xl border border-slate-200 bg-white p-4 mb-5">
          <p className="text-[12px] font-semibold text-slate-500 mb-3">How the final judge weighted each agent</p>
          <div className="space-y-2.5">
            {fd.agent_weights.map((w, i) => (
              <div key={i}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[12.5px] font-semibold" style={{ color: INK }}>{w.agent_name}</span>
                  <span className="text-[12px] font-bold text-slate-500">{Math.round(w.weight * 100)}%</span>
                </div>
                <div className="w-full h-1.5 rounded-full bg-slate-100 overflow-hidden mb-1">
                  <div className="h-full rounded-full" style={{ width: `${Math.round(w.weight * 100)}%`, background: GOLD }} />
                </div>
                <p className="text-[11.5px] text-slate-500">{w.justification}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="rounded-xl border border-slate-200 bg-white p-4">
        <p className="text-[12px] font-semibold text-slate-500 mb-2 flex items-center gap-1.5"><MessageSquare size={13} /> Reasoning</p>
        <p className="text-[13px] text-slate-600 leading-relaxed">{fd.reasoning}</p>
      </div>
    </div>
  );
}

/* ---------------- app ---------------- */
export default function HireLensApp() {
  const [screen, setScreen] = useState("dashboard"); // dashboard | flow
  const [step, setStep] = useState(0);
  const [report, setReport] = useState(null);
  const [meta, setMeta] = useState({ candidateName: "", targetRole: "", jobDescription: "" });

  const enterFlow = () => { setScreen("flow"); setStep(0); };

  const handleAnalyze = (newReport, newMeta) => {
    setReport(newReport);
    setMeta(newMeta);
    setStep(1);
  };

  // Steps beyond Setup (1-4) require a report to already exist.
  const canJump = (i) => i === 0 || !!report;

  const screens = { 0: Setup, 1: Profile, 2: Agents, 3: Debate, 4: Decision };
  const ActiveScreen = screens[step];

  return (
    <div className="w-full h-full flex" style={{ background: "#F5F6F8", fontFamily: "Inter, sans-serif", minHeight: 640 }}>
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@600;700&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');`}</style>

      {/* sidebar */}
      <aside className="w-56 shrink-0 flex flex-col py-5 px-4" style={{ background: INK }}>
        <div className="mb-8"><Logo dark /></div>
        <button onClick={() => setScreen("dashboard")} className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-[13px] font-medium mb-1"
          style={screen === "dashboard" ? { background: "rgba(255,255,255,.1)", color: "#fff" } : { color: "#8FA0C4" }}>
          <LayoutGrid size={15} /> Dashboard
        </button>
        <button onClick={enterFlow} className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-[13px] font-medium mb-6"
          style={screen === "flow" ? { background: "rgba(255,255,255,.1)", color: "#fff" } : { color: "#8FA0C4" }}>
          <Plus size={15} /> New candidate
        </button>
        <p className="text-[10px] font-semibold uppercase tracking-widest text-slate-500 px-3 mb-2">Demo examples</p>
        {RECENTS.map((r) => (
          <div key={r.name} className="text-left px-3 py-2 rounded-lg opacity-50 cursor-default">
            <p className="text-[12.5px] font-medium text-slate-200">{r.name}</p>
            <p className="text-[10.5px] font-semibold" style={{ color: REC_COLORS[r.rec] }}>{r.rec}</p>
          </div>
        ))}
      </aside>

      {/* main */}
      <div className="flex-1 flex flex-col overflow-auto">
        {screen === "flow" && (
          <div className="sticky top-0 z-10 bg-white/90 backdrop-blur border-b border-slate-200 px-10 py-3 flex items-center justify-between">
            <Stepper active={step} onJump={setStep} canJump={canJump} />
            <div className="flex gap-2">
              <button onClick={() => setStep((s) => Math.max(0, s - 1))} disabled={step === 0} className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center disabled:opacity-30"><ChevronLeft size={15} /></button>
              <button onClick={() => canJump(step + 1) && setStep((s) => Math.min(4, s + 1))} disabled={step === 4 || !canJump(step + 1)} className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center disabled:opacity-30"><ArrowRight size={15} /></button>
            </div>
          </div>
        )}
        {screen === "dashboard" ? (
          <Dashboard goSetup={enterFlow} report={report} />
        ) : (
          <ActiveScreen onAnalyze={handleAnalyze} defaults={meta} report={report} candidateName={meta.candidateName} />
        )}
      </div>
    </div>
  );
}
