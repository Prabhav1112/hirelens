import React from "react";
import ReactDOM from "react-dom/client";
import HireLensApp from "./App.jsx";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <HireLensApp />
  </React.StrictMode>
);
