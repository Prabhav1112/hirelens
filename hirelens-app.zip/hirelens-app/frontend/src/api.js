// Base URL of the FastAPI backend. Override at build time with:
//   VITE_API_BASE=http://your-host:8000 npm run dev
export const API_BASE = import.meta.env.VITE_API_BASE || "http://localhost:8000";

/**
 * Runs the full HireLens pipeline against real uploaded files.
 * @param {{resumeFile: File, transcriptFile: File, jobDescription: string, targetRole: string, generateVoice: boolean}} args
 */
export async function analyzeCandidateFiles({
  resumeFile,
  transcriptFile,
  jobDescription,
  targetRole,
  generateVoice,
}) {
  const form = new FormData();
  form.append("resume", resumeFile);
  form.append("transcript", transcriptFile);
  if (jobDescription) form.append("job_description", jobDescription);
  if (targetRole) form.append("target_role", targetRole);
  form.append("generate_voice", generateVoice ? "true" : "false");

  const res = await fetch(`${API_BASE}/api/analyze`, {
    method: "POST",
    body: form,
  });

  if (!res.ok) {
    const detail = await safeErrorDetail(res);
    throw new Error(detail || `Analysis failed (HTTP ${res.status})`);
  }
  return res.json();
}

/**
 * Runs the full HireLens pipeline against raw pasted text (no file upload).
 */
export async function analyzeCandidateText({
  resumeText,
  transcriptText,
  jobDescription,
  targetRole,
  generateVoice,
}) {
  const res = await fetch(`${API_BASE}/api/analyze-text`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      resume_text: resumeText,
      transcript_text: transcriptText,
      job_description: jobDescription || "",
      target_role: targetRole || "",
      generate_voice: !!generateVoice,
    }),
  });

  if (!res.ok) {
    const detail = await safeErrorDetail(res);
    throw new Error(detail || `Analysis failed (HTTP ${res.status})`);
  }
  return res.json();
}

export function audioUrl(path) {
  if (!path) return null;
  return path.startsWith("http") ? path : `${API_BASE}${path}`;
}

async function safeErrorDetail(res) {
  try {
    const body = await res.json();
    return body.detail || body.message || JSON.stringify(body);
  } catch {
    return null;
  }
}

export async function checkHealth() {
  try {
    const res = await fetch(`${API_BASE}/api/health`);
    return res.ok;
  } catch {
    return false;
  }
}
